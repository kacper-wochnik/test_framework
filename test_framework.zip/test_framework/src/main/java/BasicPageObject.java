import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import com.codeborne.selenide.WebDriverRunner;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.WebDriverRunner.getWebDriver;

public class BasicPageObject {

    private static final SelenideElement LOGIN_BUTTON = $(By.id("login"));
    private static final SelenideElement CHOOSE_SERVER_MODAL = $(By.xpath("//div[contains(@class, 'modal')]"));
    private static final SelenideElement COUNTRY_SERVER(String country) {
        return CHOOSE_SERVER_MODAL.$(By.xpath(".//*[contains(text(),'" + country + "')]"));
    }
    private static final SelenideElement CONTINUE_BUTTON = CHOOSE_SERVER_MODAL.$(By.xpath(".//button[contains(text(),'Continue')]"));
    private static final SelenideElement BACK_TO_DEMO_LINK = $(By.xpath("//a[contains(text(),'Back to demo')]"));
    private static final SelenideElement EXERCISE_INPUT = $(By.xpath("//input[contains(@placeholder, 'Search exercises')]"));
    private static final SelenideElement FIRST_SEARCH_RESULT = $$(By.xpath("//div[contains(@class, 'list-content-container')]")).first();
    private static final SelenideElement ADD_TO_CART_BUTTON = $(By.xpath("//button[contains(@class, 'cart')]"));
    private static final SelenideElement CART_CONTAINER_BUTTON = $(By.xpath("//div[contains(@class, 'cart-link-container')]"));
    private static final SelenideElement ASSIGN_PROGRAM_BUTTON = $(By.id("assign-program-modal-button"));
    private static final SelenideElement PATIENT_SELECTOR = $(By.xpath("//div[contains(@class, 'patient-selector')]"));
    private static final SelenideElement PATIENT_DROPDOWN_VALUE(String patient) {
        return $(By.xpath("//*[contains(text(),'Demo-patient')]"));
    }
    private static final SelenideElement ASSIGN_SELECTED_PROGRAM_MODAL_BUTTON = $(By.id("assign-protocol-button"));
    private static final SelenideElement ASSIGNED_MESSAGE = $(By.xpath("//div[contains(@class, 'assigned')]//strong[contains(text(),'Program assigned.')]"));
    private static final SelenideElement PROGRAM_CODE_LABEL = $(By.xpath("//div[contains(text(),'Program code:')]//strong"));

    public BasicPageObject startBrowserApp(String _env) {
        open(_env);
        getWebDriver().manage().window().maximize();
        System.out.println("User on env: " + _env);

        return this;
    }

    public BasicPageObject pickLogin() {
        LOGIN_BUTTON.click();
        System.out.println("Clicked on 'Login' button");

        return this;
    }

    public BasicPageObject selectServerCountry(String _country) {
        COUNTRY_SERVER(_country).click();
        System.out.println("Clicked on country server: " + _country);

        return this;
    }

    public BasicPageObject backToDemo() {
        CONTINUE_BUTTON.shouldBe(visible);
        selectServerCountry("USA");
        CONTINUE_BUTTON.click();
        BACK_TO_DEMO_LINK.click();
        System.out.println("Select 'USA' server again & 'Back to demo' link");

        return this;
    }

    public void searchExercise(String _exercise) {
        EXERCISE_INPUT.setValue(_exercise);
        System.out.println("Search box for excercise filled with value: " + _exercise);
    }

    public void clickOnFirstSearchResult() {
        FIRST_SEARCH_RESULT.click();
        System.out.println("First search result clicked");
    }

    public BasicPageObject addExercise(String _exercise) {
        searchExercise(_exercise);
        clickOnFirstSearchResult();
        ADD_TO_CART_BUTTON.click();
        System.out.println("First search result list for " + _exercise + " added to cart");

        return this;
    }

    public BasicPageObject assignPlanToPatient() {
        CART_CONTAINER_BUTTON.click();
        ASSIGN_PROGRAM_BUTTON.click();
        PATIENT_SELECTOR.click();
        PATIENT_DROPDOWN_VALUE("Demo-patient").click();
        ASSIGN_SELECTED_PROGRAM_MODAL_BUTTON.click();
        System.out.println("Plan assigned to demo patient");

        return this;
    }

    public BasicPageObject verifyProgramAssigned() {
        ASSIGNED_MESSAGE.shouldBe(visible);
        PROGRAM_CODE_LABEL.shouldBe(visible);
        System.out.println("Verification of program assignment successful");
        System.out.println("Assigned program code is: " + PROGRAM_CODE_LABEL.getText());

        return this;
    }

    public BasicPageObject endSession() {
        getWebDriver().manage().deleteAllCookies();
        WebDriverRunner.closeWebDriver();
        System.out.println("Session end");
        return this;
    }

}
