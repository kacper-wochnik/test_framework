import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class First_test extends BasicPageObject{
    private String serverCountry, env, exercise;
    private BasicPageObject basicPageObject;

    @Before
    public void setUp(){
        basicPageObject = new BasicPageObject();
        env = "https://www.physitrack.co.uk/";
        serverCountry = "USA";
        exercise = "Bird dog";
    }

    @Test
    public void firstTest() throws InterruptedException {
        //Step 1: Open https://www.physitrack.co.uk/
        basicPageObject.startBrowserApp(env);

        //Step 2: Pick Login
        basicPageObject.pickLogin();

        //Step 3: Pick USA as your country
        basicPageObject.selectServerCountry(serverCountry);

        //TBA: Additional step due to - "We detected that you're accesing Physitrack from Polish IP address"
        //Back to Demo
        basicPageObject.backToDemo();

        //Step 4: Add Bird dog to an exercise plan
        basicPageObject.addExercise(exercise);

        //Step 5: Assign plan to Demo patient
        basicPageObject.assignPlanToPatient();

        //Step 6: Validate if program was assigned to Demo patient
        basicPageObject.verifyProgramAssigned();
    }

    @After
    public void tearDown(){
        basicPageObject.endSession();
    }
}
